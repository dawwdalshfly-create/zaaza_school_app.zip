#!/usr/bin/env python3
"""يبني ملف .pack من مجلد محتوى.

الاستخدام:  python tools/make_pack.py content_dir out.pack --version 2

يتوقع المجلد: data_seed.json + books/ summaries/ videos/ teachers/
ويولّد manifest.json مع SHA-256 لكل ملف.
"""
import argparse, hashlib, json, os, zipfile, datetime

ap = argparse.ArgumentParser()
ap.add_argument("src"); ap.add_argument("out")
ap.add_argument("--version", type=int, required=True)
ap.add_argument("--school-id", default="13_june_zaaza")
a = ap.parse_args()

files, hashes = [], {}
for root, _, names in os.walk(a.src):
    for n in names:
        full = os.path.join(root, n)
        rel = os.path.relpath(full, a.src).replace(os.sep, "/")
        if rel in ("data_seed.json", "manifest.json"):
            continue
        h = hashlib.sha256()
        with open(full, "rb") as f:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                h.update(chunk)
        hashes[rel] = h.hexdigest(); files.append((full, rel))

count = lambda p: sum(1 for r in hashes if r.startswith(p))
manifest = {
    "school_id": a.school_id, "syllabus": "Yemen_Aden",
    "version_code": a.version,
    "created_at": datetime.date.today().isoformat(),
    "content_summary": {"books_count": count("books/"), "summaries_count": count("summaries/"),
                        "videos_count": count("videos/"), "teachers_count": count("teachers/")},
    "files": hashes,
}
with zipfile.ZipFile(a.out, "w", zipfile.ZIP_STORED) as z:  # الفيديو مضغوط أصلاً
    z.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2))
    z.write(os.path.join(a.src, "data_seed.json"), "data_seed.json")
    for full, rel in files:
        z.write(full, rel)
print("تم:", a.out, "|", len(files), "ملف")
