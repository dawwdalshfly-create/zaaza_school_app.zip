# تطبيق مدرسة 13 يونيو زعازع (Offline)

## التشغيل
1. ثبّت Flutter 3.16+ ثم نفّذ داخل المجلد:
   flutter create . --platforms=android
   flutter pub get
   flutter run
   (أمر create يولّد مجلد android دون أن يمس lib/ أو pubspec.yaml)
2. في android/app/build.gradle ضع minSdkVersion 21 على الأقل (pdfx يتطلب 21+).

## إنشاء حزمة محتوى
python tools/make_pack.py my_content school_content_v2.pack --version 2
انسخ الملف إلى الهاتف ثم: تبويب "المحتوى" > اختيار ملف الحزمة.
