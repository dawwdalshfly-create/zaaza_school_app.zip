import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';

class SearchHit {
  final String kind; // BOOK | SUMMARY | VIDEO | LESSON | TEACHER
  final int id;
  final String title;
  SearchHit(this.kind, this.id, this.title);
}

/// بحث محلي عبر FTS5 مع تطبيع الحروف العربية، ويعود إلى LIKE إن لم يتوفر FTS5.
class OfflineSearchEngine {
  static bool _fts = true;

  static String normalize(String s) {
    return s
        .replaceAll(RegExp('[\u064B-\u065F\u0670\u0640]'), '') // التشكيل والتطويل
        .replaceAll(RegExp('[إأآ]'), 'ا')
        .replaceAll('ى', 'ي')
        .replaceAll('ة', 'ه')
        .toLowerCase();
  }

  static Future<void> createIndexTable(Database db) async {
    try {
      await db.execute(
          'CREATE VIRTUAL TABLE search_index USING fts5(kind UNINDEXED, item_id UNINDEXED, title, body)');
      _fts = true;
    } catch (_) {
      _fts = false;
      await db.execute(
          'CREATE TABLE search_index (kind TEXT, item_id INTEGER, title TEXT, body TEXT)');
    }
  }

  static Future<void> _detect(Database db) async {
    final r = await db.rawQuery(
        "SELECT sql FROM sqlite_master WHERE name='search_index'");
    _fts = r.isNotEmpty && (r.first['sql'] as String).toUpperCase().contains('FTS5');
  }

  static Future<void> rebuild(Database db) async {
    await db.delete('search_index');
    final batch = db.batch();
    void add(String kind, Object id, String title, [String? body]) {
      batch.insert('search_index', {
        'kind': kind,
        'item_id': id,
        'title': normalize(title),
        'body': normalize(body ?? ''),
      });
    }

    for (final r in await db.query('lessons')) {
      add('LESSON', r['id']!, '${r['lesson_title']}', '${r['unit_title']}');
    }
    for (final r in await db.query('books')) {
      add('BOOK', r['id']!, '${r['title']}');
    }
    for (final r in await db.query('summaries')) {
      add('SUMMARY', r['id']!, '${r['title']}', r['text_content'] as String?);
    }
    for (final r in await db.query('videos')) {
      add('VIDEO', r['id']!, '${r['title']}');
    }
    for (final r in await db.query('teachers')) {
      add('TEACHER', r['id']!, '${r['name']}', '${r['subject_name']}');
    }
    await batch.commit(noResult: true);
  }

  static Future<List<SearchHit>> search(String query) async {
    final q = normalize(query.trim());
    if (q.isEmpty) return [];
    final db = await AppDatabase.instance.database;
    await _detect(db);

    List<Map<String, Object?>> rows;
    if (_fts) {
      final terms = q
          .split(RegExp(r'\s+'))
          .where((t) => t.isNotEmpty)
          .map((t) => '"${t.replaceAll('"', '')}"*')
          .join(' ');
      try {
        rows = await db.rawQuery(
            'SELECT kind, item_id, title FROM search_index WHERE search_index MATCH ? ORDER BY rank LIMIT 60',
            [terms]);
      } catch (_) {
        rows = await _like(db, q);
      }
    } else {
      rows = await _like(db, q);
    }
    return rows
        .map((r) => SearchHit(r['kind'] as String, int.parse('${r['item_id']}'), r['title'] as String))
        .toList();
  }

  static Future<List<Map<String, Object?>>> _like(Database db, String q) =>
      db.rawQuery(
          'SELECT kind, item_id, title FROM search_index WHERE title LIKE ? OR body LIKE ? LIMIT 60',
          ['%$q%', '%$q%']);
}
