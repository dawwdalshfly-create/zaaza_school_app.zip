import 'dart:convert';
import 'dart:io';
import 'package:archive/archive_io.dart';
import 'package:crypto/crypto.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';
import '../search/offline_search_engine.dart';
import '../storage/file_storage_service.dart';

class ImportResult {
  final bool success;
  final String message;
  ImportResult(this.success, this.message);
}

/// يستورد ملف .pack (ZIP) من USB/SD دون حذف المفضلة وسجلات الطالب.
class ContentPackImporter {
  // ترتيب الإدخال مهم بسبب المفاتيح الأجنبية
  static const _tables = [
    'grades',
    'subjects',
    'lessons',
    'teachers',
    'books',
    'summaries',
    'videos',
  ];

  static Future<ImportResult> importPack(
    File packFile, {
    void Function(String status)? onStatus,
  }) async {
    InputFileStream? input;
    try {
      onStatus?.call('فتح الحزمة...');
      input = InputFileStream(packFile.path); // قراءة متدفقة بدون تحميل الملف كله
      final archive = ZipDecoder().decodeBuffer(input);

      ArchiveFile? manifestFile;
      ArchiveFile? seedFile;
      for (final f in archive) {
        if (f.name == 'manifest.json') manifestFile = f;
        if (f.name == 'data_seed.json') seedFile = f;
      }
      if (manifestFile == null || seedFile == null) {
        return ImportResult(false, 'حزمة غير صالحة: manifest.json أو data_seed.json مفقود.');
      }

      final manifest = jsonDecode(utf8.decode(manifestFile.content as List<int>)) as Map<String, dynamic>;
      final seed = jsonDecode(utf8.decode(seedFile.content as List<int>)) as Map<String, dynamic>;
      final int newVersion = manifest['version_code'] as int;

      final db = await AppDatabase.instance.database;
      final current = Sqflite.firstIntValue(
              await db.rawQuery('SELECT MAX(version_code) FROM content_versions')) ??
          0;
      if (newVersion <= current) {
        return ImportResult(false, 'الإصدار المثبت ($current) مساوٍ أو أحدث من الحزمة ($newVersion).');
      }

      final root = await FileStorageService.root();
      final hashes = Map<String, dynamic>.from((manifest['files'] as Map?) ?? {});
      final extracted = <File>[];

      // استخراج ملفاً ملفاً مع حماية Zip Slip
      var i = 0;
      final total = archive.files.where((f) => f.isFile).length;
      for (final f in archive) {
        if (!f.isFile) continue;
        i++;
        if (f.name == 'manifest.json' || f.name == 'data_seed.json') continue;

        final outPath = p.normalize(p.join(root.path, f.name));
        if (!p.isWithin(root.path, outPath)) {
          await _cleanup(extracted);
          return ImportResult(false, 'حزمة مرفوضة: مسار غير آمن (${f.name}).');
        }
        onStatus?.call('استخراج $i / $total');
        final outFile = File(outPath);
        await outFile.parent.create(recursive: true);
        final out = OutputFileStream(outPath);
        f.writeContent(out);
        await out.close();
        extracted.add(outFile);

        // التحقق من SHA-256 لكل ملف إن وُجد في manifest
        final expected = hashes[f.name] as String?;
        if (expected != null) {
          final actual = (await sha256.bind(outFile.openRead()).first).toString();
          if (actual.toLowerCase() != expected.toLowerCase()) {
            await _cleanup(extracted);
            return ImportResult(false, 'فشل التحقق من سلامة الملف: ${f.name}');
          }
        }
      }

      onStatus?.call('تحديث قاعدة البيانات...');
      await db.transaction((txn) async {
        for (final t in _tables) {
          final rows = seed[t] as List?;
          if (rows == null) continue;
          for (final r in rows) {
            await _upsert(txn, t, Map<String, Object?>.from(r as Map));
          }
        }
        if (seed['teacher_of_the_month'] != null) {
          await txn.delete('teacher_of_the_month');
          for (final r in seed['teacher_of_the_month'] as List) {
            await txn.insert('teacher_of_the_month', Map<String, Object?>.from(r as Map));
          }
        }
        await txn.insert('content_versions', {
          'version_code': newVersion,
          'pack_name': manifest['school_id'] ?? 'school_pack_v$newVersion',
        });
      });

      onStatus?.call('فهرسة البحث...');
      await OfflineSearchEngine.rebuild(db);
      return ImportResult(true, 'تم استيراد الحزمة بنجاح (الإصدار $newVersion).');
    } catch (e) {
      return ImportResult(false, 'حدث خطأ أثناء الاستيراد: $e');
    } finally {
      await input?.close();
    }
  }

  /// تحديث أو إدراج دون REPLACE، لأن REPLACE يحذف الصف
  /// فتُحذف سجلات القراءة والمشاهدة عبر ON DELETE CASCADE.
  static Future<void> _upsert(Transaction txn, String table, Map<String, Object?> row) async {
    final id = row['id'];
    final updated = await txn.update(table, row, where: 'id = ?', whereArgs: [id]);
    if (updated == 0) await txn.insert(table, row);
  }

  static Future<void> _cleanup(List<File> files) async {
    for (final f in files) {
      try {
        if (await f.exists()) await f.delete();
      } catch (_) {}
    }
  }
}
