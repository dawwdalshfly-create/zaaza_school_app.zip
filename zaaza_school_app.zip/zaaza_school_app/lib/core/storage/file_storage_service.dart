import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

/// يدير مجلد المحتوى المحلي. المسارات في القاعدة نسبية دائماً.
class FileStorageService {
  static Directory? _root;

  static Future<Directory> root() async {
    if (_root != null) return _root!;
    final docs = await getApplicationDocumentsDirectory();
    final dir = Directory(p.join(docs.path, 'school_content'));
    if (!await dir.exists()) await dir.create(recursive: true);
    _root = dir;
    return dir;
  }

  /// يحوّل مساراً نسبياً (مثل books/grade9_chemistry.pdf) إلى مسار كامل.
  static Future<String> resolve(String relativePath) async {
    final r = await root();
    return p.join(r.path, relativePath);
  }

  static Future<bool> exists(String relativePath) async =>
      File(await resolve(relativePath)).exists();
}
