import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../search/offline_search_engine.dart';

class AppDatabase {
  static final AppDatabase instance = AppDatabase._init();
  static Database? _database;
  AppDatabase._init();

  Future<Database> get database async {
    _database ??= await _initDB('zaaza_school_offline.db');
    return _database!;
  }

  Future<Database> _initDB(String fileName) async {
    final path = join(await getDatabasesPath(), fileName);
    return openDatabase(
      path,
      version: 1,
      onConfigure: (db) => db.execute('PRAGMA foreign_keys = ON'),
      onCreate: _createDB,
    );
  }

  Future<void> _createDB(Database db, int version) async {
    const stmts = [
      '''CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_name TEXT NOT NULL,
        grade_id INTEGER NOT NULL,
        school_name TEXT DEFAULT 'مدرسة 13 يونيو زعازع',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''',
      '''CREATE TABLE grades (
        id INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        syllabus_type TEXT DEFAULT 'عدن')''',
      '''CREATE TABLE subjects (
        id INTEGER PRIMARY KEY,
        grade_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        icon_name TEXT,
        FOREIGN KEY (grade_id) REFERENCES grades(id) ON DELETE CASCADE)''',
      '''CREATE TABLE lessons (
        id INTEGER PRIMARY KEY,
        subject_id INTEGER NOT NULL,
        unit_title TEXT NOT NULL,
        lesson_title TEXT NOT NULL,
        order_index INTEGER DEFAULT 0,
        FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE)''',
      '''CREATE TABLE books (
        id INTEGER PRIMARY KEY,
        subject_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        file_path TEXT NOT NULL,
        file_size_mb REAL,
        total_pages INTEGER DEFAULT 0,
        FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE)''',
      '''CREATE TABLE summaries (
        id INTEGER PRIMARY KEY,
        lesson_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        file_path TEXT NOT NULL,
        type TEXT CHECK(type IN ('PDF','TEXT','IMAGE')),
        text_content TEXT,
        FOREIGN KEY (lesson_id) REFERENCES lessons(id) ON DELETE CASCADE)''',
      '''CREATE TABLE teachers (
        id INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        subject_name TEXT NOT NULL,
        bio TEXT,
        photo_path TEXT,
        grades_taught TEXT)''',
      '''CREATE TABLE videos (
        id INTEGER PRIMARY KEY,
        lesson_id INTEGER NOT NULL,
        teacher_id INTEGER,
        title TEXT NOT NULL,
        file_path TEXT NOT NULL,
        duration_seconds INTEGER DEFAULT 0,
        FOREIGN KEY (lesson_id) REFERENCES lessons(id) ON DELETE CASCADE,
        FOREIGN KEY (teacher_id) REFERENCES teachers(id) ON DELETE SET NULL)''',
      '''CREATE TABLE teacher_of_the_month (
        id INTEGER PRIMARY KEY,
        teacher_id INTEGER NOT NULL,
        month_year TEXT NOT NULL,
        achievements TEXT,
        FOREIGN KEY (teacher_id) REFERENCES teachers(id) ON DELETE CASCADE)''',
      '''CREATE TABLE reading_history (
        book_id INTEGER PRIMARY KEY,
        last_page INTEGER DEFAULT 1,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE)''',
      '''CREATE TABLE watch_history (
        video_id INTEGER PRIMARY KEY,
        last_position_sec INTEGER DEFAULT 0,
        completed INTEGER DEFAULT 0,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (video_id) REFERENCES videos(id) ON DELETE CASCADE)''',
      '''CREATE TABLE favorites (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        item_type TEXT CHECK(item_type IN ('BOOK','SUMMARY','VIDEO')),
        item_id INTEGER NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(item_type, item_id))''',
      '''CREATE TABLE content_versions (
        version_code INTEGER PRIMARY KEY,
        imported_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        pack_name TEXT)''',
    ];
    for (final s in stmts) {
      await db.execute(s);
    }
    await OfflineSearchEngine.createIndexTable(db);
    await _seed(db);
    await OfflineSearchEngine.rebuild(db);
  }

  Future<void> _seed(Database db) async {
    const grades = {
      9: 'الصف التاسع الأساسي',
      10: 'الصف الأول الثانوي',
      11: 'الصف الثاني الثانوي',
      12: 'الصف الثالث الثانوي',
    };
    for (final e in grades.entries) {
      await db.insert('grades', {'id': e.key, 'name': e.value, 'syllabus_type': 'عدن'});
    }

    const subjects = [
      [1, 'القرآن الكريم وعلومه', 'quran'],
      [2, 'التربية الإسلامية', 'islamic'],
      [3, 'اللغة العربية', 'arabic'],
      [4, 'الرياضيات', 'math'],
      [5, 'العلوم (كيمياء/فيزياء/أحياء)', 'science'],
      [6, 'الدراسات الاجتماعية', 'social'],
      [7, 'اللغة الإنجليزية', 'english'],
    ];
    for (final s in subjects) {
      await db.insert('subjects', {'id': s[0], 'grade_id': 9, 'name': s[1], 'icon_name': s[2]});
    }

    await db.insert('teachers', {
      'id': 1,
      'name': 'أ. أحمد علي الزعزعي',
      'subject_name': 'العلوم والكيمياء',
      'bio': 'معلم بمدرسة 13 يونيو زعازع، خبرة 15 عاماً في المنهج اليمني.',
      'photo_path': '',
      'grades_taught': 'الصف التاسع, الصف الأول الثانوي',
    });
    await db.insert('teacher_of_the_month', {
      'id': 1,
      'teacher_id': 1,
      'month_year': 'سبتمبر 2026',
      'achievements': 'جهّز تجارب الكيمياء العملية لطلاب التاسع والأول الثانوي للعمل بدون إنترنت.',
    });
  }
}
