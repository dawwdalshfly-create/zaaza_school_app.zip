import 'package:sqflite/sqflite.dart';
import 'app_database.dart';

typedef DbRow = Map<String, dynamic>;

class Repo {
  static Future<Database> get _db => AppDatabase.instance.database;

  // ---- الطالب ----
  static Future<DbRow?> currentUser() async {
    final rows = await (await _db).query('users', orderBy: 'id DESC', limit: 1);
    return rows.isEmpty ? null : rows.first;
  }

  static Future<void> saveUser(String name, int gradeId) async {
    final db = await _db;
    await db.delete('users');
    await db.insert('users', {'student_name': name, 'grade_id': gradeId});
  }

  static Future<List<DbRow>> grades() async =>
      (await _db).query('grades', orderBy: 'id');

  // ---- المنهج ----
  static Future<List<DbRow>> subjects(int gradeId) async => (await _db)
      .query('subjects', where: 'grade_id = ?', whereArgs: [gradeId], orderBy: 'id');

  static Future<List<DbRow>> lessons(int subjectId) async => (await _db).query(
      'lessons', where: 'subject_id = ?', whereArgs: [subjectId], orderBy: 'order_index, id');

  static Future<List<DbRow>> booksBySubject(int subjectId) async => (await _db)
      .query('books', where: 'subject_id = ?', whereArgs: [subjectId], orderBy: 'id');

  static Future<List<DbRow>> summariesByLesson(int lessonId) async => (await _db)
      .query('summaries', where: 'lesson_id = ?', whereArgs: [lessonId], orderBy: 'id');

  static Future<List<DbRow>> videosByLesson(int lessonId) async => (await _db)
      .query('videos', where: 'lesson_id = ?', whereArgs: [lessonId], orderBy: 'id');

  static Future<DbRow?> byId(String table, int id) async {
    final rows = await (await _db).query(table, where: 'id = ?', whereArgs: [id]);
    return rows.isEmpty ? null : rows.first;
  }

  // ---- المعلم المثالي ----
  static Future<DbRow?> teacherOfMonth() async {
    final rows = await (await _db).rawQuery('''
      SELECT t.*, m.month_year, m.achievements
      FROM teacher_of_the_month m JOIN teachers t ON t.id = m.teacher_id
      ORDER BY m.id DESC LIMIT 1''');
    return rows.isEmpty ? null : rows.first;
  }

  // ---- القراءة والمشاهدة ----
  static Future<int> lastPage(int bookId) async {
    final r = await (await _db)
        .query('reading_history', where: 'book_id = ?', whereArgs: [bookId]);
    return r.isEmpty ? 1 : r.first['last_page'] as int;
  }

  static Future<void> saveLastPage(int bookId, int page) async {
    await (await _db).insert(
      'reading_history',
      {'book_id': bookId, 'last_page': page, 'updated_at': DateTime.now().toIso8601String()},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  static Future<void> updateTotalPages(int bookId, int pages) async {
    await (await _db).update('books', {'total_pages': pages},
        where: 'id = ?', whereArgs: [bookId]);
  }

  static Future<int> savedPosition(int videoId) async {
    final r = await (await _db)
        .query('watch_history', where: 'video_id = ?', whereArgs: [videoId]);
    return r.isEmpty ? 0 : r.first['last_position_sec'] as int;
  }

  static Future<void> saveWatch(int videoId, int pos, bool done) async {
    await (await _db).insert(
      'watch_history',
      {
        'video_id': videoId,
        'last_position_sec': pos,
        'completed': done ? 1 : 0,
        'updated_at': DateTime.now().toIso8601String(),
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // ---- المفضلة ----
  static Future<bool> isFavorite(String type, int id) async {
    final r = await (await _db).query('favorites',
        where: 'item_type = ? AND item_id = ?', whereArgs: [type, id]);
    return r.isNotEmpty;
  }

  static Future<bool> toggleFavorite(String type, int id) async {
    final db = await _db;
    if (await isFavorite(type, id)) {
      await db.delete('favorites',
          where: 'item_type = ? AND item_id = ?', whereArgs: [type, id]);
      return false;
    }
    await db.insert('favorites', {'item_type': type, 'item_id': id});
    return true;
  }

  /// يعيد المفضلة كعناصر {type, id, title}
  static Future<List<DbRow>> favorites() async {
    return (await _db).rawQuery('''
      SELECT 'BOOK' AS type, b.id AS id, b.title AS title, f.created_at AS created_at
        FROM favorites f JOIN books b ON f.item_type='BOOK' AND f.item_id=b.id
      UNION ALL
      SELECT 'SUMMARY', s.id, s.title, f.created_at
        FROM favorites f JOIN summaries s ON f.item_type='SUMMARY' AND f.item_id=s.id
      UNION ALL
      SELECT 'VIDEO', v.id, v.title, f.created_at
        FROM favorites f JOIN videos v ON f.item_type='VIDEO' AND f.item_id=v.id
      ORDER BY created_at DESC''');
  }

  // ---- الإصدارات ----
  static Future<int> currentVersion() async {
    final r = await (await _db).rawQuery('SELECT MAX(version_code) AS v FROM content_versions');
    return (r.first['v'] as int?) ?? 0;
  }
}
