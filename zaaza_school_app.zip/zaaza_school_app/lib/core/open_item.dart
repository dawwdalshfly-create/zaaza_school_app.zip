import 'package:flutter/material.dart';
import 'database/repository.dart';
import '../features/books/pdf_reader_screen.dart';
import '../features/summaries/summary_viewer.dart';
import '../features/videos/offline_video_player.dart';

/// يفتح عنصراً (كتاب/ملخص/فيديو) حسب نوعه ومعرّفه.
Future<void> openItem(BuildContext context, String kind, int id) async {
  final nav = Navigator.of(context);
  switch (kind) {
    case 'BOOK':
      final b = await Repo.byId('books', id);
      if (b == null) return;
      nav.push(MaterialPageRoute(
        builder: (_) => PdfReaderScreen(
          title: b['title'] as String,
          relativePath: b['file_path'] as String,
          bookId: id,
        ),
      ));
      break;
    case 'VIDEO':
      final v = await Repo.byId('videos', id);
      if (v == null) return;
      nav.push(MaterialPageRoute(
        builder: (_) => OfflineVideoPlayerScreen(
          videoId: id,
          videoTitle: v['title'] as String,
          relativePath: v['file_path'] as String,
        ),
      ));
      break;
    case 'SUMMARY':
      final s = await Repo.byId('summaries', id);
      if (s == null) return;
      nav.push(MaterialPageRoute(builder: (_) => SummaryViewer(summary: s)));
      break;
  }
}
