import 'package:flutter/material.dart';

class AppTheme {
  static const _green = Color(0xFF1F5C4A);
  static const _amber = Color(0xFFC8862B);

  static ThemeData light() {
    final scheme = ColorScheme.fromSeed(
      seedColor: _green,
      secondary: _amber,
      surface: const Color(0xFFF6F1E7),
    );
    return _base(scheme);
  }

  static ThemeData dark() {
    final scheme = ColorScheme.fromSeed(
      seedColor: _green,
      secondary: _amber,
      brightness: Brightness.dark,
    );
    return _base(scheme);
  }

  static ThemeData _base(ColorScheme s) => ThemeData(
        useMaterial3: true,
        colorScheme: s,
        scaffoldBackgroundColor: s.surface,
        appBarTheme: AppBarTheme(
          backgroundColor: s.surface,
          foregroundColor: s.onSurface,
          elevation: 0,
          centerTitle: false,
        ),
        listTileTheme: const ListTileThemeData(minVerticalPadding: 10),
        cardTheme: CardTheme(
          elevation: 0,
          color: s.surfaceContainerHighest.withOpacity(0.5),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
      );
}
