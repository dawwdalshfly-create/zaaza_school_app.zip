import 'package:flutter/material.dart';
import 'package:pdfx/pdfx.dart';
import '../../core/database/repository.dart';
import '../../core/storage/file_storage_service.dart';

/// قارئ PDF محلي. إن مُرِّر bookId يحفظ آخر صفحة ويعيد فتحها.
class PdfReaderScreen extends StatefulWidget {
  final String title;
  final String relativePath;
  final int? bookId;
  const PdfReaderScreen({super.key, required this.title, required this.relativePath, this.bookId});

  @override
  State<PdfReaderScreen> createState() => _PdfReaderScreenState();
}

class _PdfReaderScreenState extends State<PdfReaderScreen> {
  PdfControllerPinch? _controller;
  String? _error;
  int _page = 1;
  int _pages = 0;
  bool _fav = false;

  @override
  void initState() {
    super.initState();
    _open();
  }

  Future<void> _open() async {
    try {
      final path = await FileStorageService.resolve(widget.relativePath);
      if (!await FileStorageService.exists(widget.relativePath)) {
        setState(() => _error = 'الملف غير موجود. استورد حزمة المحتوى أولاً.');
        return;
      }
      final start = widget.bookId == null ? 1 : await Repo.lastPage(widget.bookId!);
      if (widget.bookId != null) _fav = await Repo.isFavorite('BOOK', widget.bookId!);
      final doc = PdfDocument.openFile(path);
      _controller = PdfControllerPinch(document: doc, initialPage: start);
      final d = await doc;
      _pages = d.pagesCount;
      if (widget.bookId != null) Repo.updateTotalPages(widget.bookId!, _pages);
      if (mounted) setState(() => _page = start);
    } catch (e) {
      if (mounted) setState(() => _error = 'تعذّر فتح الكتاب: $e');
    }
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        actions: [
          if (widget.bookId != null)
            IconButton(
              icon: Icon(_fav ? Icons.favorite : Icons.favorite_border),
              onPressed: () async {
                final v = await Repo.toggleFavorite('BOOK', widget.bookId!);
                setState(() => _fav = v);
              },
            ),
        ],
      ),
      body: _error != null
          ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(_error!)))
          : _controller == null
              ? const Center(child: CircularProgressIndicator())
              : Column(children: [
                  Expanded(
                    child: PdfViewPinch(
                      controller: _controller!,
                      onPageChanged: (p) {
                        _page = p;
                        if (widget.bookId != null) Repo.saveLastPage(widget.bookId!, p);
                        setState(() {});
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8),
                    child: Text('صفحة $_page${_pages > 0 ? ' من $_pages' : ''}'),
                  ),
                ]),
    );
  }
}
