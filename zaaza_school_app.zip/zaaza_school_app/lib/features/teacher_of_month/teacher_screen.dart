import 'dart:io';
import 'package:flutter/material.dart';
import '../../core/database/repository.dart';
import '../../core/storage/file_storage_service.dart';

class TeacherScreen extends StatelessWidget {
  const TeacherScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('المعلم المثالي')),
      body: FutureBuilder<DbRow?>(
        future: Repo.teacherOfMonth(),
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          final r = snap.data;
          if (r == null) return const Center(child: Text('لم يُحدَّد معلم مثالي هذا الشهر.'));
          return ListView(
            padding: const EdgeInsets.all(24),
            children: [
              Center(child: _Photo(path: r['photo_path'] as String?)),
              const SizedBox(height: 16),
              Text(r['name'] as String,
                  textAlign: TextAlign.center,
                  style: t.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Text('${r['subject_name']} - ${r['month_year']}',
                  textAlign: TextAlign.center, style: t.textTheme.bodyLarge),
              if ((r['grades_taught'] as String?)?.isNotEmpty ?? false) ...[
                const SizedBox(height: 4),
                Text('يدرّس: ${r['grades_taught']}', textAlign: TextAlign.center),
              ],
              const SizedBox(height: 24),
              if ((r['bio'] as String?)?.isNotEmpty ?? false)
                Text(r['bio'] as String, style: const TextStyle(fontSize: 16, height: 1.7)),
              const SizedBox(height: 16),
              if ((r['achievements'] as String?)?.isNotEmpty ?? false) ...[
                Text('الإنجازات', style: t.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
                const SizedBox(height: 6),
                Text(r['achievements'] as String, style: const TextStyle(fontSize: 16, height: 1.7)),
              ],
            ],
          );
        },
      ),
    );
  }
}

class _Photo extends StatelessWidget {
  final String? path;
  const _Photo({this.path});

  @override
  Widget build(BuildContext context) {
    if (path == null || path!.isEmpty) {
      return const CircleAvatar(radius: 56, child: Icon(Icons.person, size: 56));
    }
    return FutureBuilder<String>(
      future: FileStorageService.resolve(path!),
      builder: (context, snap) {
        final f = snap.hasData ? File(snap.data!) : null;
        if (f == null || !f.existsSync()) {
          return const CircleAvatar(radius: 56, child: Icon(Icons.person, size: 56));
        }
        return CircleAvatar(radius: 56, backgroundImage: FileImage(f));
      },
    );
  }
}
