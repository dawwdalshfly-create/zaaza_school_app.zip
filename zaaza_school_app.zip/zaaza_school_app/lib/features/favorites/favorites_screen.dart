import 'package:flutter/material.dart';
import '../../core/database/repository.dart';
import '../../core/open_item.dart';

const _icons = {
  'BOOK': Icons.picture_as_pdf,
  'VIDEO': Icons.play_circle_outline,
  'SUMMARY': Icons.description_outlined,
};

class FavoritesScreen extends StatefulWidget {
  const FavoritesScreen({super.key});
  @override
  State<FavoritesScreen> createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends State<FavoritesScreen> {
  late Future<List<DbRow>> _future = Repo.favorites();

  void _reload() => setState(() => _future = Repo.favorites());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('المفضلة'),
        actions: [IconButton(icon: const Icon(Icons.refresh), onPressed: _reload)],
      ),
      body: FutureBuilder<List<DbRow>>(
        future: _future,
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final items = snap.data!;
          if (items.isEmpty) {
            return const Center(child: Text('لم تضف شيئاً بعد. اضغط على القلب داخل أي كتاب أو فيديو أو ملخص.'));
          }
          return ListView(children: [
            for (final f in items)
              ListTile(
                leading: Icon(_icons[f['type']]),
                title: Text(f['title'] as String),
                trailing: IconButton(
                  icon: const Icon(Icons.favorite),
                  onPressed: () async {
                    await Repo.toggleFavorite(f['type'] as String, f['id'] as int);
                    _reload();
                  },
                ),
                onTap: () => openItem(context, f['type'] as String, f['id'] as int),
              ),
          ]);
        },
      ),
    );
  }
}
