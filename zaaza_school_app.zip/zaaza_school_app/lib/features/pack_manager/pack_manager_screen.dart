import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../../core/database/repository.dart';
import '../../core/importer/content_pack_importer.dart';

class PackManagerScreen extends StatefulWidget {
  const PackManagerScreen({super.key});
  @override
  State<PackManagerScreen> createState() => _PackManagerScreenState();
}

class _PackManagerScreenState extends State<PackManagerScreen> {
  bool _busy = false;
  String _status = '';
  String? _result;
  bool _ok = false;
  int _version = 0;

  @override
  void initState() {
    super.initState();
    _loadVersion();
  }

  Future<void> _loadVersion() async {
    final v = await Repo.currentVersion();
    if (mounted) setState(() => _version = v);
  }

  Future<void> _pick() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.any);
    final path = res?.files.single.path;
    if (path == null) return;
    if (!path.toLowerCase().endsWith('.pack')) {
      setState(() {
        _ok = false;
        _result = 'اختر ملفاً بامتداد .pack';
      });
      return;
    }
    setState(() {
      _busy = true;
      _result = null;
      _status = '';
    });
    final r = await ContentPackImporter.importPack(
      File(path),
      onStatus: (s) => mounted ? setState(() => _status = s) : null,
    );
    await _loadVersion();
    if (mounted) {
      setState(() {
        _busy = false;
        _ok = r.success;
        _result = r.message;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('حزم المحتوى')),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          Text(_version == 0 ? 'لم تُستورد أي حزمة بعد.' : 'إصدار المحتوى الحالي: $_version',
              style: t.textTheme.titleMedium),
          const SizedBox(height: 8),
          const Text('انسخ ملف .pack إلى الهاتف من فلاشة USB أو بطاقة SD، ثم اخترْه هنا. لن تُحذف مفضلتك ولا سجل قراءتك.'),
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: _busy ? null : _pick,
            icon: const Icon(Icons.folder_open),
            label: const Text('اختيار ملف الحزمة'),
          ),
          if (_busy) ...[
            const SizedBox(height: 24),
            const LinearProgressIndicator(),
            const SizedBox(height: 8),
            Text(_status),
          ],
          if (_result != null) ...[
            const SizedBox(height: 24),
            Text(_result!, style: TextStyle(color: _ok ? t.colorScheme.primary : t.colorScheme.error, fontWeight: FontWeight.w700)),
          ],
        ],
      ),
    );
  }
}
