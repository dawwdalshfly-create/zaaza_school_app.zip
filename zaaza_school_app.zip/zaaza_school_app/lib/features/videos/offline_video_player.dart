import 'dart:io';
import 'package:chewie/chewie.dart';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import '../../core/database/repository.dart';
import '../../core/storage/file_storage_service.dart';

class OfflineVideoPlayerScreen extends StatefulWidget {
  final int videoId;
  final String videoTitle;
  final String relativePath;

  const OfflineVideoPlayerScreen({
    super.key,
    required this.videoId,
    required this.videoTitle,
    required this.relativePath,
  });

  @override
  State<OfflineVideoPlayerScreen> createState() => _OfflineVideoPlayerScreenState();
}

class _OfflineVideoPlayerScreenState extends State<OfflineVideoPlayerScreen> {
  VideoPlayerController? _video;
  ChewieController? _chewie;
  String? _error;
  bool _fav = false;
  DateTime _lastSave = DateTime.fromMillisecondsSinceEpoch(0);

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final path = await FileStorageService.resolve(widget.relativePath);
    final file = File(path);
    if (!await file.exists()) {
      setState(() => _error = 'ملف الفيديو غير موجود. استورد حزمة المحتوى أولاً.');
      return;
    }
    _fav = await Repo.isFavorite('VIDEO', widget.videoId);
    final saved = await Repo.savedPosition(widget.videoId);

    final c = VideoPlayerController.file(file);
    try {
      await c.initialize();
    } catch (e) {
      setState(() => _error = 'تعذّر تشغيل الفيديو: $e');
      return;
    }
    if (saved > 0 && saved < c.value.duration.inSeconds - 3) {
      await c.seekTo(Duration(seconds: saved));
    }
    _video = c;
    _chewie = ChewieController(
      videoPlayerController: c,
      autoPlay: true,
      aspectRatio: c.value.aspectRatio,
      allowFullScreen: true,
    );
    c.addListener(_saveProgress);
    if (mounted) setState(() {});
  }

  void _saveProgress() {
    final c = _video;
    if (c == null || !c.value.isInitialized) return;
    if (DateTime.now().difference(_lastSave).inSeconds < 5) return;
    _lastSave = DateTime.now();
    _persist();
  }

  void _persist() {
    final c = _video;
    if (c == null || !c.value.isInitialized) return;
    final pos = c.value.position.inSeconds;
    final done = pos >= c.value.duration.inSeconds - 3;
    Repo.saveWatch(widget.videoId, done ? 0 : pos, done);
  }

  @override
  void dispose() {
    _video?.removeListener(_saveProgress);
    _persist();
    _chewie?.dispose();
    _video?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.videoTitle),
        actions: [
          IconButton(
            icon: Icon(_fav ? Icons.favorite : Icons.favorite_border),
            onPressed: () async {
              final v = await Repo.toggleFavorite('VIDEO', widget.videoId);
              setState(() => _fav = v);
            },
          ),
        ],
      ),
      body: _error != null
          ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(_error!)))
          : _chewie == null
              ? const Center(child: CircularProgressIndicator())
              : Chewie(controller: _chewie!),
    );
  }
}
