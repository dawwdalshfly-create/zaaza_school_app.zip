import 'package:flutter/material.dart';
import '../favorites/favorites_screen.dart';
import '../pack_manager/pack_manager_screen.dart';
import '../search/search_screen.dart';
import '../subjects/subjects_screen.dart';
import '../teacher_of_month/teacher_screen.dart';

class HomeScreen extends StatefulWidget {
  final Map<String, dynamic> user;
  const HomeScreen({super.key, required this.user});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      SubjectsScreen(user: widget.user),
      const SearchScreen(),
      const FavoritesScreen(),
      const TeacherScreen(),
      const PackManagerScreen(),
    ];
    return Scaffold(
      body: IndexedStack(index: _index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'المواد'),
          NavigationDestination(icon: Icon(Icons.search), label: 'بحث'),
          NavigationDestination(icon: Icon(Icons.favorite_border), selectedIcon: Icon(Icons.favorite), label: 'المفضلة'),
          NavigationDestination(icon: Icon(Icons.emoji_events_outlined), selectedIcon: Icon(Icons.emoji_events), label: 'المعلم'),
          NavigationDestination(icon: Icon(Icons.usb_outlined), selectedIcon: Icon(Icons.usb), label: 'المحتوى'),
        ],
      ),
    );
  }
}
