import 'package:flutter/material.dart';
import '../../core/open_item.dart';
import '../../core/search/offline_search_engine.dart';

const _labels = {
  'BOOK': 'كتاب',
  'SUMMARY': 'ملخص',
  'VIDEO': 'فيديو',
  'LESSON': 'درس',
  'TEACHER': 'معلم',
};

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});
  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  List<SearchHit> _hits = [];
  bool _searched = false;

  Future<void> _run(String q) async {
    final r = await OfflineSearchEngine.search(q);
    if (mounted) setState(() {
      _hits = r;
      _searched = q.trim().isNotEmpty;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: TextField(
          autofocus: false,
          decoration: const InputDecoration(hintText: 'ابحث في الكتب والدروس والفيديوهات', border: InputBorder.none),
          onChanged: _run,
        ),
      ),
      body: _searched && _hits.isEmpty
          ? const Center(child: Text('لا نتائج. جرّب كلمة أخرى.'))
          : ListView.separated(
              itemCount: _hits.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (context, i) {
                final h = _hits[i];
                return ListTile(
                  title: Text(h.title),
                  subtitle: Text(_labels[h.kind] ?? h.kind),
                  onTap: () => openItem(context, h.kind, h.id),
                );
              },
            ),
    );
  }
}
