import 'dart:io';
import 'package:flutter/material.dart';
import '../../core/database/repository.dart';
import '../../core/storage/file_storage_service.dart';
import '../books/pdf_reader_screen.dart';

class SummaryViewer extends StatefulWidget {
  final DbRow summary;
  const SummaryViewer({super.key, required this.summary});
  @override
  State<SummaryViewer> createState() => _SummaryViewerState();
}

class _SummaryViewerState extends State<SummaryViewer> {
  bool _fav = false;

  @override
  void initState() {
    super.initState();
    Repo.isFavorite('SUMMARY', widget.summary['id'] as int)
        .then((v) => mounted ? setState(() => _fav = v) : null);
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.summary;
    final type = s['type'] as String?;
    if (type == 'PDF') {
      return PdfReaderScreen(title: s['title'] as String, relativePath: s['file_path'] as String);
    }
    return Scaffold(
      appBar: AppBar(
        title: Text(s['title'] as String),
        actions: [
          IconButton(
            icon: Icon(_fav ? Icons.favorite : Icons.favorite_border),
            onPressed: () async {
              final v = await Repo.toggleFavorite('SUMMARY', s['id'] as int);
              setState(() => _fav = v);
            },
          ),
        ],
      ),
      body: type == 'IMAGE'
          ? FutureBuilder<String>(
              future: FileStorageService.resolve(s['file_path'] as String),
              builder: (context, snap) {
                if (!snap.hasData) return const Center(child: CircularProgressIndicator());
                final f = File(snap.data!);
                if (!f.existsSync()) return const Center(child: Text('الصورة غير موجودة.'));
                return InteractiveViewer(child: Center(child: Image.file(f)));
              },
            )
          : SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: SelectableText(
                (s['text_content'] as String?) ?? '',
                style: const TextStyle(fontSize: 18, height: 1.8),
              ),
            ),
    );
  }
}
