import 'package:flutter/material.dart';
import '../../core/database/repository.dart';
import '../../core/open_item.dart';

const _icons = {
  'quran': Icons.auto_stories,
  'islamic': Icons.mosque,
  'arabic': Icons.translate,
  'math': Icons.calculate,
  'science': Icons.science,
  'social': Icons.public,
  'english': Icons.language,
};

class SubjectsScreen extends StatelessWidget {
  final Map<String, dynamic> user;
  const SubjectsScreen({super.key, required this.user});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('أهلاً ${user['student_name']}')),
      body: FutureBuilder<List<DbRow>>(
        future: Repo.subjects(user['grade_id'] as int),
        builder: (context, snap) {
          final subjects = snap.data ?? [];
          if (snap.connectionState == ConnectionState.done && subjects.isEmpty) {
            return const Center(child: Text('لا توجد مواد لهذا الصف بعد. استورد حزمة المحتوى من تبويب المحتوى.'));
          }
          return GridView.count(
            padding: const EdgeInsets.all(16),
            crossAxisCount: 2,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.15,
            children: [
              for (final s in subjects)
                Card(
                  clipBehavior: Clip.antiAlias,
                  child: InkWell(
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => SubjectDetailScreen(subject: s))),
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Icon(_icons[s['icon_name']] ?? Icons.book,
                              size: 32, color: Theme.of(context).colorScheme.primary),
                          Text(s['name'] as String,
                              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                        ],
                      ),
                    ),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}

class SubjectDetailScreen extends StatelessWidget {
  final DbRow subject;
  const SubjectDetailScreen({super.key, required this.subject});

  @override
  Widget build(BuildContext context) {
    final id = subject['id'] as int;
    return Scaffold(
      appBar: AppBar(title: Text(subject['name'] as String)),
      body: FutureBuilder<List<List<DbRow>>>(
        future: Future.wait([Repo.booksBySubject(id), Repo.lessons(id)]),
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final books = snap.data![0];
          final lessons = snap.data![1];
          if (books.isEmpty && lessons.isEmpty) {
            return const Center(child: Text('لا يوجد محتوى لهذه المادة بعد.'));
          }
          String? lastUnit;
          return ListView(
            children: [
              if (books.isNotEmpty) const _Header('الكتب'),
              for (final b in books)
                ListTile(
                  leading: const Icon(Icons.picture_as_pdf),
                  title: Text(b['title'] as String),
                  onTap: () => openItem(context, 'BOOK', b['id'] as int),
                ),
              if (lessons.isNotEmpty) const _Header('الدروس'),
              for (final l in lessons) ...[
                if (l['unit_title'] != lastUnit && (lastUnit = l['unit_title'] as String) != '')
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                    child: Text(l['unit_title'] as String,
                        style: TextStyle(color: Theme.of(context).colorScheme.secondary, fontWeight: FontWeight.w700)),
                  ),
                ListTile(
                  title: Text(l['lesson_title'] as String),
                  trailing: const Icon(Icons.chevron_left),
                  onTap: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => LessonScreen(lesson: l))),
                ),
              ],
            ],
          );
        },
      ),
    );
  }
}

class LessonScreen extends StatelessWidget {
  final DbRow lesson;
  const LessonScreen({super.key, required this.lesson});

  @override
  Widget build(BuildContext context) {
    final id = lesson['id'] as int;
    return Scaffold(
      appBar: AppBar(title: Text(lesson['lesson_title'] as String)),
      body: FutureBuilder<List<List<DbRow>>>(
        future: Future.wait([Repo.videosByLesson(id), Repo.summariesByLesson(id)]),
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final videos = snap.data![0];
          final sums = snap.data![1];
          if (videos.isEmpty && sums.isEmpty) {
            return const Center(child: Text('لا توجد فيديوهات أو ملخصات لهذا الدرس بعد.'));
          }
          return ListView(children: [
            if (videos.isNotEmpty) const _Header('الفيديوهات'),
            for (final v in videos)
              ListTile(
                leading: const Icon(Icons.play_circle_outline),
                title: Text(v['title'] as String),
                onTap: () => openItem(context, 'VIDEO', v['id'] as int),
              ),
            if (sums.isNotEmpty) const _Header('الملخصات'),
            for (final s in sums)
              ListTile(
                leading: const Icon(Icons.description_outlined),
                title: Text(s['title'] as String),
                onTap: () => openItem(context, 'SUMMARY', s['id'] as int),
              ),
          ]);
        },
      ),
    );
  }
}

class _Header extends StatelessWidget {
  final String text;
  const _Header(this.text);
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
        child: Text(text, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
      );
}
