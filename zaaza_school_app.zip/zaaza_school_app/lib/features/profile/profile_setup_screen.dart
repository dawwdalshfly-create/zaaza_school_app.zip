import 'package:flutter/material.dart';
import '../../core/database/repository.dart';
import '../home/home_screen.dart';

class ProfileSetupScreen extends StatefulWidget {
  const ProfileSetupScreen({super.key});
  @override
  State<ProfileSetupScreen> createState() => _ProfileSetupScreenState();
}

class _ProfileSetupScreenState extends State<ProfileSetupScreen> {
  final _name = TextEditingController();
  int? _gradeId;
  List<DbRow> _grades = [];

  @override
  void initState() {
    super.initState();
    Repo.grades().then((g) => setState(() => _grades = g));
  }

  Future<void> _save() async {
    final name = _name.text.trim();
    if (name.isEmpty || _gradeId == null) return;
    await Repo.saveUser(name, _gradeId!);
    final user = await Repo.currentUser();
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => HomeScreen(user: user!)));
  }

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            const SizedBox(height: 32),
            Text('مدرسة 13 يونيو زعازع',
                style: t.textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Text('المنهج اليمني - عدن. يعمل بدون إنترنت.',
                style: t.textTheme.bodyLarge),
            const SizedBox(height: 32),
            TextField(
              controller: _name,
              decoration: const InputDecoration(
                  labelText: 'اسم الطالب', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<int>(
              value: _gradeId,
              decoration: const InputDecoration(
                  labelText: 'الصف الدراسي', border: OutlineInputBorder()),
              items: [
                for (final g in _grades)
                  DropdownMenuItem(value: g['id'] as int, child: Text(g['name'] as String)),
              ],
              onChanged: (v) => setState(() => _gradeId = v),
            ),
            const SizedBox(height: 24),
            FilledButton(onPressed: _save, child: const Text('ابدأ الدراسة')),
          ],
        ),
      ),
    );
  }
}
